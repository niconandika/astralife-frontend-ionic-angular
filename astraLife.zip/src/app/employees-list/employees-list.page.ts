import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.page.html',
  styleUrls: ['./employees-list.page.scss'],
})
export class EmployeesListPage implements OnInit {

  employeesData: any;

  constructor(
    public apiService: ApiService
  ) {
    this.employeesData = [];
  }

  ngOnInit() {
    // this.getAllEmployees();
  }

  ionViewWillEnter() {
    this.getAllEmployees();
  }

  getAllEmployees() {
    this.apiService.getList().subscribe(response => {
      console.log(response);
      this.employeesData = response;
    })
  }


  delete(item) {
    this.apiService.deleteItem(item.id).subscribe(Response => {
      //Update list after delete is successful
      this.getAllEmployees();
    });
  }

}

