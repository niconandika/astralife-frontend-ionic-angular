import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees-detail',
  templateUrl: './employees-detail.page.html',
  styleUrls: ['./employees-detail.page.scss'],
})
export class EmployeesDetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
