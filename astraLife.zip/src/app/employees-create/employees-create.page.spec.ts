import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EmployeesCreatePage } from './employees-create.page';

describe('EmployeesCreatePage', () => {
  let component: EmployeesCreatePage;
  let fixture: ComponentFixture<EmployeesCreatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeesCreatePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EmployeesCreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
