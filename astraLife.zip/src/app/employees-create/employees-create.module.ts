import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EmployeesCreatePageRoutingModule } from './employees-create-routing.module';

import { EmployeesCreatePage } from './employees-create.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EmployeesCreatePageRoutingModule
  ],
  declarations: [EmployeesCreatePage]
})
export class EmployeesCreatePageModule {}
