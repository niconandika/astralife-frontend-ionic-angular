import { Component, OnInit } from '@angular/core';
import { Employees } from '../models/employees';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employees-create',
  templateUrl: './employees-create.page.html',
  styleUrls: ['./employees-create.page.scss'],
})
export class EmployeesCreatePage implements OnInit {

  data: Employees

  constructor(
    public apiService: ApiService,
    public router: Router
  ) {
    this.data = new Employees();
  }

  ngOnInit() {
  }

  submitForm() {
    this.apiService.createItem(this.data).subscribe((response) => {
      this.router.navigate(['employees-list']);
    });

  }

}
