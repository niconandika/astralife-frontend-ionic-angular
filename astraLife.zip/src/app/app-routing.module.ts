import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'employees-list', pathMatch: 'full' },
  {
    path: 'employees-create',
    loadChildren: () => import('./employees-create/employees-create.module').then( m => m.EmployeesCreatePageModule)
  },
  {
    path: 'employees-edit/:id',
    loadChildren: () => import('./employees-edit/employees-edit.module').then( m => m.EmployeesEditPageModule)
  },
  {
    path: 'employees-list',
    loadChildren: () => import('./employees-list/employees-list.module').then( m => m.EmployeesListPageModule)
  },
  {
    path: 'employees-detail',
    loadChildren: () => import('./employees-detail/employees-detail.module').then( m => m.EmployeesDetailPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
