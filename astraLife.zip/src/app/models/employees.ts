export class Employees {
	id: number;
	nik: string;
	name: string;
	division: string;
	position: string;
	type: string;
	lastposition: string;
	createddate: string;
}
